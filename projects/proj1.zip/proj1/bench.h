#define NUMSLOTS 5

void fetchBin(int bin, int slot);
int binInSlot(int slot);

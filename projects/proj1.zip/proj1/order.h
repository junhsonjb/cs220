int openOrder(char * orderFile);
void closeOrder();
int nextPartNumber();
int fetchNextPart();
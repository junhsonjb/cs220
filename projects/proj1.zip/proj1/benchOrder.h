void clearBench();
void getWidget(int partNumber);
void printEarnings();